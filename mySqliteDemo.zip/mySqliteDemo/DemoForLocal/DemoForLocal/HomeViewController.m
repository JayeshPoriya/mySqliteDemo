
//

#import "HomeViewController.h"
#import "HomeTableViewCell.h"
#import "DBManager.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Home";
    
    //====table register
    [tblHome registerNib:[UINib nibWithNibName:@"HomeTableViewCell" bundle:nil] forCellReuseIdentifier:@"myCell"];
    tblHome.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    DBManager * db = [[DBManager alloc] init];
    arrayOfAllData = [[NSMutableArray alloc] init];
    
    arrayOfAllData = [db getAllDataFromTblHome];
    NSLog(@"arrayOfAllData ==> %@",arrayOfAllData);
    [tblHome reloadData];
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - All Action

- (IBAction)btnSaveAction:(id)sender {
    
    
    
    
    DBManager * db = [[DBManager alloc] init];
    db.first_name = txtFirstName.text;
    db.last_name = txtLastName.text;
    
    
    if ([btnSaveAndUpdate.titleLabel.text isEqualToString:@"Save"])
        [db insertTblHome];
    else
        [db updateTblHome:strHomeID];
    
    
    
    [arrayOfAllData removeAllObjects];
    arrayOfAllData = [[NSMutableArray alloc] init];
    
    arrayOfAllData = [db getAllDataFromTblHome];
    NSLog(@"arrayOfAllData ==> %@",arrayOfAllData);
    [tblHome reloadData];
    
    txtFirstName.text = @"";
    txtLastName.text = @"";
    strHomeID = @"";
    
    [btnSaveAndUpdate setTitle:@"Save" forState:UIControlStateNormal];

    
}

- (IBAction)btnClearAction:(id)sender {
    
    txtFirstName.text = @"";
    txtLastName.text = @"";
    strHomeID = @"";
    
    [btnSaveAndUpdate setTitle:@"Save" forState:UIControlStateNormal];
    
}

-(void)deleteRecord:(NSInteger)theTag {
    
    NSLog(@"theTag ==> %ld",(long)theTag);
    
    strHomeIDForDeleteRecord = [NSString stringWithFormat:@"%@",[[arrayOfAllData objectAtIndex:theTag] valueForKey:@"homeID"]];
    
    //=========================UIAlertController (UIAlertAction)============= //==OR You Want To Use UIAlertView :)
    
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:@"Home"
                                  message:@"Do you want to delete this record?"
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* Yes = [UIAlertAction
                         actionWithTitle:@"Yes"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             
                             DBManager * db = [[DBManager alloc] init];
                             [db deleteMessage:[strHomeIDForDeleteRecord intValue]];
                             
                             arrayOfAllData = [db getAllDataFromTblHome];
                             NSLog(@"arrayOfAllData ==> %@",arrayOfAllData);
                             [tblHome reloadData];

                             
                             
//                             NSLog(@"Yes Delete");
                             [alert dismissViewControllerAnimated:YES completion:nil];
                         }];
    UIAlertAction* No = [UIAlertAction
                             actionWithTitle:@"No"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
//                                 NSLog(@"No Delete");
                                 [alert dismissViewControllerAnimated:YES completion:nil];
                             }];
    
    [alert addAction:Yes];
    [alert addAction:No];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrayOfAllData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeTableViewCell * cell = (HomeTableViewCell*)[tblHome dequeueReusableCellWithIdentifier:@"myCell"];
    cell.lblFullName.text = [NSString stringWithFormat:@"%@ %@",[[arrayOfAllData objectAtIndex:indexPath.row]valueForKey:@"first_name"],[[arrayOfAllData objectAtIndex:indexPath.row]valueForKey:@"last_name"]];
    cell.btnDelete.tag = indexPath.row;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [btnSaveAndUpdate setTitle:@"Update" forState:UIControlStateNormal];

    txtFirstName.text = [NSString stringWithFormat:@"%@",[[arrayOfAllData objectAtIndex:indexPath.row] valueForKey:@"first_name"]];
    txtLastName.text = [NSString stringWithFormat:@"%@",[[arrayOfAllData objectAtIndex:indexPath.row] valueForKey:@"last_name"]];
    strHomeID = [NSString stringWithFormat:@"%@",[[arrayOfAllData objectAtIndex:indexPath.row] valueForKey:@"homeID"]];

}

@end
