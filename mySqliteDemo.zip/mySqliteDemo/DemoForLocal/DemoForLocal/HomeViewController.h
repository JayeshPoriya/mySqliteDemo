
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    __weak IBOutlet UITextField *txtLastName;
    __weak IBOutlet UITextField *txtFirstName;
    
    __weak IBOutlet UITableView *tblHome;
    
    __weak IBOutlet UIButton *btnSaveAndUpdate;
    NSMutableArray * arrayOfAllData;
    
    
    NSString * strHomeID;
    NSString * strHomeIDForDeleteRecord;

    
}
- (IBAction)btnSaveAction:(id)sender;
- (IBAction)btnClearAction:(id)sender;
-(void)deleteRecord:(NSInteger)theTag;



@end
