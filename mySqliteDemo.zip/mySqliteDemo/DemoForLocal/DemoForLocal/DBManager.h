
//

#import <Foundation/Foundation.h>

@interface DBManager : NSObject


@property (nonatomic,retain) NSString * first_name;
@property (nonatomic,retain) NSString * last_name;


-(NSMutableArray *)getAllDataFromTblHome;
-(void)insertTblHome;
-(void)updateTblHome:(NSString *)ids;
-(void)deleteMessage:(int)homeID;


@end
