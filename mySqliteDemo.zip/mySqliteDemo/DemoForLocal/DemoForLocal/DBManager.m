
//

#import "DBManager.h"
#import <sqlite3.h>
#import "AppDelegate.h"


@implementation DBManager


//===get data from tbl home 
-(NSMutableArray *)getAllDataFromTblHome
{
    @try
    {
        NSMutableArray * arrayOfMessage = [[NSMutableArray alloc]init];
        sqlite3_stmt *select_exceptions=nil;
        NSString *str_exceptions= @"select * from tblHome";
        const char *sql=[str_exceptions UTF8String];
        sqlite3 *db =[AppDelegate getNewDBConnection];  //open databasa
        
        
        if(sqlite3_prepare_v2(db, sql,-1, &select_exceptions,NULL)==SQLITE_OK)
        {
            NSString *first_name,*last_name;
            int homeID;
            
            NSInteger ab=0;
            while(sqlite3_step(select_exceptions)==SQLITE_ROW)
            {
                homeID =sqlite3_column_int(select_exceptions,0);
                
                
                
                if ((char *)sqlite3_column_text(select_exceptions,1) == NULL)
                    first_name = @"";
                else
                    first_name=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,1) encoding:NSUTF8StringEncoding];
                
                
                
                
                if ((char *)sqlite3_column_text(select_exceptions,2) == NULL)
                    last_name = @"";
                else
                    last_name=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,2) encoding:NSUTF8StringEncoding];
                
                
                NSMutableDictionary * tempDict = [[NSMutableDictionary alloc]init];
                [tempDict setObject:[NSString stringWithFormat:@"%d",homeID] forKey:@"homeID"];
                [tempDict setObject:first_name forKey:@"first_name"];
                [tempDict setObject:last_name forKey:@"last_name"];
                [arrayOfMessage addObject:tempDict];
                ab++;
            }
        }
        else
        {
            NSLog(@"Could not Compile Properly.....");
        }
        sqlite3_finalize(select_exceptions);
        sqlite3_close(db);
        //        NSLog(@"All User From DBManager arrayOfMessage %@",arrayOfMessage);
        return arrayOfMessage;
    }
    @catch (NSException *exception) {
        NSLog(@"exception ==> %@",exception);
    }
}

//====insert data
-(void)insertTblHome
{
    
    @try {
        
        sqlite3 *db =[AppDelegate getNewDBConnection];
        sqlite3_stmt *stmt;
        
        NSString *sqlInsert =  [NSString stringWithFormat:@"insert into tblHome([first_name],[last_name]) values(?,?)"];
        
        if(sqlite3_prepare_v2(db, [sqlInsert UTF8String], -1, &stmt, NULL) == SQLITE_OK)
        {
            sqlite3_bind_text(stmt, 1, [self.first_name UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 2, [self.last_name UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_reset(stmt); //=======Execute==========
        }
        //        NSLog(@"sqlInsert ==> %@",sqlInsert);

        if(SQLITE_DONE != sqlite3_step(stmt))
        {
            NSLog( @"Error while inserting data: '%s'", sqlite3_errmsg(db));
        }
    }
    @catch (NSException *exception)
    {
        NSLog(@"exception ==> %@",exception);
    }
}

//=====update data
-(void)updateTblHome:(NSString *)ids
{
    sqlite3 *db =[AppDelegate getNewDBConnection];
    NSString *query = nil;
    
    query = [NSString stringWithFormat:@"update tblHome set first_name = '%@',last_name = '%@' where id in ('%@')",self.first_name,self.last_name, ids];
    NSLog(@"Query..%@",query);
    sqlite3_stmt *compiledStatement;
    
    if(sqlite3_prepare_v2(db, [query UTF8String], -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        if(SQLITE_DONE != sqlite3_step(compiledStatement))
        {
            NSLog( @"Error while updating data: '%s'", sqlite3_errmsg(db));
        }
        sqlite3_reset(compiledStatement);
    }else
    {
        NSLog( @"Error while updating '%s'", sqlite3_errmsg(db));
    }
    sqlite3_finalize(compiledStatement);
    sqlite3_close(db);
}


//=====delete data
-(void)deleteMessage:(int)homeID
{
    sqlite3_stmt *deleteStmt=nil;
    
    NSString *strDelete;
    strDelete=[NSString stringWithFormat:@"delete from tblHome where id = '%d'",homeID];
    //    NSLog(@"setDelete ==> %@",strDelete);
    
    const char *sql=[strDelete UTF8String];
    sqlite3 *db = [AppDelegate getNewDBConnection];
    
    if(sqlite3_prepare_v2(db,sql,-1,&deleteStmt,NULL)==SQLITE_OK)
    {
        if(sqlite3_step(deleteStmt)==SQLITE_DONE)
        {
            //            NSLog(@"Message Deleted Successfully...");
        }
        else
        {
            NSLog(@"Problem in Deleting User...");
        }
    }
    else
    {
        NSLog(@"Problem While compiling delete User statement..");
    }
    
    sqlite3_finalize(deleteStmt);
    sqlite3_close(db);
}

@end
