
//

#import "HomeTableViewCell.h"
#import "HomeViewController.h"


@implementation HomeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnDeleteAction:(id)sender {
    
//    NSLog(@"view ==> %@",self.superview.superview.superview);
    if ([self.superview.superview.superview.nextResponder isKindOfClass:[HomeViewController class]])
    {
        UIButton *button = (UIButton *)sender;
//        NSLog(@"%ld", (long)[button tag]);
        [(HomeViewController *)self.superview.superview.superview.nextResponder deleteRecord:[button tag]];
        
    }
    
}

@end
